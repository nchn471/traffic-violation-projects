"use client";

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/shared/ui/dialog";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/shared/ui/tabs";
import { Eye, Settings } from "lucide-react";
import type { Camera } from "@/lib/types/api/v1/camera";
import { CameraLiveViewTab } from "./live-view-tab/camera-live-view-tab";
import { CameraConfigurationTab } from "./config-tab/camera-config-tab";
import { useCameraDialog } from "../hooks/use-camera-dialog";

interface CameraDialogProps {
  camera: Camera;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function CameraDialog({
  camera,
  open,
  onOpenChange,
}: CameraDialogProps) {
  const { videoList, isSaving, error, handleUpdate } = useCameraDialog(camera);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-6xl max-h-[90vh] p-0">
        <Tabs defaultValue="config" className="flex-1">
          <DialogHeader className="border-b border-border px-6 py-4 space-y-2">
            <DialogTitle className="text-lg font-semibold text-foreground">
              {camera.name}
            </DialogTitle>

            <TabsList className="grid w-full grid-cols-2 bg-muted/30">
              <TabsTrigger value="live" className="flex items-center gap-2 text-sm">
                <Eye className="h-4 w-4" />
                <span className="hidden sm:inline">Live</span>
              </TabsTrigger>
              <TabsTrigger value="config" className="flex items-center gap-2 text-sm">
                <Settings className="h-4 w-4" />
                <span className="hidden sm:inline">Config</span>
              </TabsTrigger>
            </TabsList>
          </DialogHeader>

          <div className="mt-2 max-h-[calc(90vh-180px)] overflow-y-auto custom-scrollbar">
            <TabsContent value="live" className="px-6 pb-6">
              <CameraLiveViewTab camera={camera} />
            </TabsContent>

            <TabsContent value="config" className="px-6 pb-6">
              <CameraConfigurationTab
                camera={camera}
                videoList={videoList}
                isSaving={isSaving}
                error={error}
                onCameraUpdate={handleUpdate}
              />
            </TabsContent>
          </div>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
