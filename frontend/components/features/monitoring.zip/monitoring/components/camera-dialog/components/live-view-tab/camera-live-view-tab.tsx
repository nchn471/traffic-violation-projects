"use client"
import { Wifi, WifiOff } from "lucide-react"
import type { Camera } from "@/lib/types/api/v1/camera"

interface CameraLiveViewTabProps {
  camera: Camera
}

export function CameraLiveViewTab({ camera }: CameraLiveViewTabProps) {

  const isOnline = Math.random() > 0.3

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Live Stream</h3>
        <div className="flex items-center gap-2">
          {isOnline ? (
            <>
              <Wifi className="h-4 w-4 text-green-500" />
              <span className="text-sm text-green-600">Online</span>
            </>
          ) : (
            <>
              <WifiOff className="h-4 w-4 text-red-500" />
              <span className="text-sm text-red-600">Offline</span>
            </>
          )}
        </div>
      </div>

      <div className="aspect-video bg-muted rounded flex items-center justify-center">
        <p className="text-muted-foreground">Live view for {camera.name}</p>
      </div>

    </div>
  )
}
