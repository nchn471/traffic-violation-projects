"use client"

import { useEffect, useState, useCallback } from "react"
import { updateCamera, getCameraVideos } from "@/lib/api/v1/camera"
import type { Camera } from "@/lib/types/api/v1/camera"

export function useCameraDialog(camera: Camera) {
  const [videoList, setVideoList] = useState<string[]>([])
  const [isLoadingVideos, setIsLoadingVideos] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const fetchVideoList = useCallback(async () => {
    setIsLoadingVideos(true)
    setError(null)
    try {
      const videos = await getCameraVideos(camera.id)
      setVideoList(videos)
    } catch (err) {
      console.error("Failed to fetch videos", err)
      setError("Failed to load video list.")
    } finally {
      setIsLoadingVideos(false)
    }
  }, [camera.id])

  useEffect(() => {
    fetchVideoList()
  }, [fetchVideoList])

  const handleUpdate = useCallback(
    async (updatedCamera: Camera) => {
      setIsSaving(true)
      setError(null)
      try {
        await updateCamera(updatedCamera.id, updatedCamera)
      } catch (err) {
        console.error("Failed to update camera", err)
        setError("Failed to update camera configuration.")
      } finally {
        setIsSaving(false)
      }
    },
    [],
  )

  return {
    videoList,
    isLoadingVideos,
    isSaving,
    error,
    handleUpdate,
  }
}
