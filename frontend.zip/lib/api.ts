import axios, { type AxiosResponse } from "axios"

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000"

const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    "Content-Type": "application/json",
  },
})

// Auth interfaces
export interface LoginRequest {
  username: string
  password: string
}

export interface RegisterRequest {
  name?: string
  username: string
  password: string
  role: string
}

export interface TokenResponse {
  access_token: string
  refresh_token: string
  token_type: string
}

export interface RefreshTokenRequest {
  refresh_token: string
}

export interface OfficerOut {
  id: string
  name: string
  username: string
  role: string
  created_at: string
}

// Camera interfaces
export interface CameraOut {
  id: string
  name: string
  location: string
  folder_path: string
  created_at: string
  updated_at: string
}

export interface CameraCreate {
  name: string
  location: string
  folder_path: string
}

export interface CameraUpdate {
  name?: string | null
  location?: string | null
  folder_path?: string | null
}

// Violation interfaces
export interface ViolationOut {
  id: string
  camera_id: string
  timestamp: string
  vehicle_type: string | null
  violation_type: string
  license_plate: string | null
  confidence: number | null
  frame_image_path: string
  vehicle_image_path: string
  lp_image_path: string | null
  status: string | null
  version_id: string | null
}

export interface ViolationCreate {
  camera_id: string
  timestamp: string
  vehicle_type: string | null
  violation_type: string
  license_plate: string | null
  confidence: number | null
  frame_image_path: string
  vehicle_image_path: string
  lp_image_path: string | null
  status?: string | null
}

export interface ViolationUpdate {
  vehicle_type?: string | null
  violation_type?: string | null
  license_plate?: string | null
  confidence?: number | null
  status?: string | null
  frame_image_path?: string | null
  vehicle_image_path?: string | null
  lp_image_path?: string | null
}

export interface ViolationVersionOut {
  id: string
  violation_id: string
  officer_id: string
  timestamp: string
  vehicle_type: string | null
  violation_type: string
  license_plate: string | null
  confidence: number | null
  frame_image_path: string
  vehicle_image_path: string
  lp_image_path: string | null
  updated_at: string
  change_type: string
}

export interface Pagination {
  page: number
  limit: number
  total: number
  totalPages: number
}

export interface PaginatedViolations {
  pagination: Pagination
  data: ViolationOut[]
}

// Ticket interfaces
export interface TicketOut {
  id: string
  amount: number
  name: string | null
  email: string | null
  notes: string | null
  violation_id: string | null
  officer_id: string | null
  status: string | null
  issued_at: string | null
  violation?: ViolationOut | null
  officer?: OfficerOut | null
}

export interface TicketCreate {
  amount: number
  name?: string | null
  email?: string | null
  notes?: string | null
  violation_id?: string | null
  officer_id?: string | null
  status?: string | null
  issued_at?: string | null
}

export interface TicketUpdate {
  amount?: number | null
  name?: string | null
  email?: string | null
  notes?: string | null
}

// Statistics interfaces
export interface StatsOverview {
  total_violations: number
  average_per_day: number
  processed_ratio: number
  violations_by_type: Record<string, number>
  violations_by_camera: Record<string, number>
}

export interface WeekdayStats {
  weekday: string
  count: number
}

export interface WeeklyViolationStats {
  data: WeekdayStats[]
}

export interface HourlyStats {
  hour: number
  count: number
}

export interface HourlyViolationStats {
  data: HourlyStats[]
}

export interface ProcessingStats {
  processed: number
  unprocessed: number
  ratio: number
}

// Add auth token to requests
apiClient.interceptors.request.use((config) => {
  const token = localStorage.getItem("access_token")
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

// Handle auth errors
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem("access_token")
      localStorage.removeItem("refresh_token")
      window.location.href = "/"
    }
    return Promise.reject(error)
  },
)

const api = {
  // Health endpoints
  ping: (): Promise<AxiosResponse<any>> => apiClient.get("/ping"),
  root: (): Promise<AxiosResponse<any>> => apiClient.get("/"),

  // Media endpoint
  getMedia: (filePath: string): Promise<AxiosResponse<Blob>> =>
    apiClient.get(`/api/v1/media/${filePath}`, { responseType: "blob" }),

  // Auth endpoints
  login: (data: LoginRequest): Promise<AxiosResponse<TokenResponse>> => apiClient.post("/api/v1/auth/login", data),

  register: (data: RegisterRequest): Promise<AxiosResponse<TokenResponse>> =>
    apiClient.post("/api/v1/auth/register", data),

  refreshToken: (data: RefreshTokenRequest): Promise<AxiosResponse<TokenResponse>> =>
    apiClient.post("/api/v1/auth/refresh", data),

  getCurrentUser: (): Promise<AxiosResponse<OfficerOut>> => apiClient.get("/api/v1/auth/me"),

  // Camera endpoints
  getCameras: (): Promise<AxiosResponse<CameraOut[]>> => apiClient.get("/api/v1/cameras/"),

  getCamera: (id: string): Promise<AxiosResponse<CameraOut>> => apiClient.get(`/api/v1/cameras/${id}`),

  createCamera: (data: CameraCreate): Promise<AxiosResponse<CameraOut>> => apiClient.post("/api/v1/cameras/", data),

  updateCamera: (id: string, data: CameraUpdate): Promise<AxiosResponse<CameraOut>> =>
    apiClient.patch(`/api/v1/cameras/${id}`, data),

  deleteCamera: (id: string): Promise<AxiosResponse<void>> => apiClient.delete(`/api/v1/cameras/${id}`),

  getCameraVideos: (id: string): Promise<AxiosResponse<string[]>> => apiClient.get(`/api/v1/cameras/${id}/videos`),

  // Violation endpoints
  getViolations: (params?: {
    page?: number
    limit?: number
    status?: string
    violation_type?: string
  }): Promise<AxiosResponse<PaginatedViolations>> => apiClient.get("/api/v1/violations", { params }),

  getViolation: (id: string): Promise<AxiosResponse<ViolationOut>> => apiClient.get(`/api/v1/violations/${id}`),

  createViolation: (data: ViolationCreate): Promise<AxiosResponse<ViolationOut>> =>
    apiClient.post("/api/v1/violations", data),

  updateViolation: (id: string, data: ViolationUpdate): Promise<AxiosResponse<ViolationOut>> =>
    apiClient.patch(`/api/v1/violations/${id}`, data),

  archiveViolation: (id: string): Promise<AxiosResponse<ViolationOut>> => apiClient.delete(`/api/v1/violations/${id}`),

  getViolationHistory: (id: string): Promise<AxiosResponse<ViolationVersionOut[]>> =>
    apiClient.get(`/api/v1/violations/${id}/history`),

  rollbackViolation: (id: string, versionId: string): Promise<AxiosResponse<ViolationOut>> =>
    apiClient.post(`/api/v1/violations/${id}/rollback/${versionId}`),

  // Statistics endpoints
  getStatsOverview: (): Promise<AxiosResponse<StatsOverview>> => apiClient.get("/api/v1/stats/overview"),

  getWeeklyStats: (): Promise<AxiosResponse<WeeklyViolationStats>> => apiClient.get("/api/v1/stats/by-weekday"),

  getHourlyStats: (): Promise<AxiosResponse<HourlyViolationStats>> => apiClient.get("/api/v1/stats/by-hour"),

  getProcessingStats: (): Promise<AxiosResponse<ProcessingStats>> => apiClient.get("/api/v1/stats/processing-ratio"),

  // Ticket endpoints
  createTicket: (violationId: string, data: TicketCreate): Promise<AxiosResponse<TicketOut>> =>
    apiClient.post(`/api/v1/tickets/${violationId}`, data),

  getTicket: (id: string): Promise<AxiosResponse<TicketOut>> => apiClient.get(`/api/v1/tickets/${id}`),

  updateTicket: (id: string, data: TicketUpdate): Promise<AxiosResponse<TicketOut>> =>
    apiClient.patch(`/api/v1/tickets/${id}`, data),

  archiveTicket: (id: string): Promise<AxiosResponse<TicketOut>> => apiClient.delete(`/api/v1/tickets/${id}`),

  rollbackTicket: (id: string, versionId: string): Promise<AxiosResponse<TicketOut>> =>
    apiClient.post(`/api/v1/tickets/${id}/rollback/${versionId}`),

  markTicketPaid: (id: string): Promise<AxiosResponse<TicketOut>> => apiClient.post(`/api/v1/tickets/${id}/mark-paid`),

  getTicketPdf: (id: string): Promise<AxiosResponse<Blob>> =>
    apiClient.get(`/api/v1/tickets/${id}/pdf`, { responseType: "blob" }),

  sendTicketEmail: (id: string): Promise<AxiosResponse<TicketOut>> => apiClient.post(`/api/v1/tickets/${id}/send`),

  // Helper function to get image URL
  getImageUrl: (imagePath: string | null): string | null => {
    if (!imagePath) return null
    return `${API_BASE_URL}/api/v1/media/${imagePath}`
  },
}

export default api
