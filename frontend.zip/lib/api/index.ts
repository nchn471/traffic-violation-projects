import { authApi } from "./auth"
import { camerasApi } from "./cameras"
import { violationsApi } from "./violations"
import { ticketsApi } from "./tickets"
import { statsApi } from "./stats"
import { mediaApi } from "./media"
import { healthApi } from "./health"
import { apiClient } from "./client"

export * from "./types"
export { authApi }
export { camerasApi }
export { violationsApi }
export { ticketsApi }
export { statsApi }
export { mediaApi }
export { healthApi }
export { apiClient }

// Convenience object for backward compatibility
export const api = {
  // Auth
  login: authApi.login,
  register: authApi.register,
  refreshToken: authApi.refreshToken,
  getCurrentUser: authApi.getCurrentUser,
  logout: authApi.logout,
  isAuthenticated: authApi.isAuthenticated,

  // Cameras
  getCameras: camerasApi.getAll,
  getCamera: camerasApi.getById,
  createCamera: camerasApi.create,
  updateCamera: camerasApi.update,
  deleteCamera: camerasApi.delete,
  getCameraVideos: camerasApi.getVideos,

  // Violations
  getViolations: violationsApi.getAll,
  getViolation: violationsApi.getById,
  createViolation: violationsApi.create,
  updateViolation: violationsApi.update,
  archiveViolation: violationsApi.archive,
  getViolationHistory: violationsApi.getHistory,
  rollbackViolation: violationsApi.rollback,

  // Tickets
  createTicket: ticketsApi.create,
  getTicket: ticketsApi.getById,
  updateTicket: ticketsApi.update,
  archiveTicket: ticketsApi.archive,
  rollbackTicket: ticketsApi.rollback,
  markTicketPaid: ticketsApi.markPaid,
  getTicketPdf: ticketsApi.getPdf,
  sendTicketEmail: ticketsApi.sendEmail,

  // Stats
  getStatsOverview: statsApi.getOverview,
  getWeeklyStats: statsApi.getWeeklyStats,
  getHourlyStats: statsApi.getHourlyStats,
  getProcessingStats: statsApi.getProcessingStats,

  // Media
  getMediaFile: mediaApi.getFile,
  getImageUrl: mediaApi.getImageUrl,

  // Health
  ping: healthApi.ping,
  root: healthApi.root,
}

export default api
