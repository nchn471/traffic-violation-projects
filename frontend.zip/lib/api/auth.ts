import { apiClient } from "./client"
import type { LoginRequest, RegisterRequest, TokenResponse, RefreshTokenRequest, OfficerOut } from "./types"

export const authApi = {
  async login(credentials: LoginRequest): Promise<TokenResponse> {
    const response = await apiClient.login(credentials)
    return response.data
  },

  async register(data: RegisterRequest): Promise<TokenResponse> {
    const response = await apiClient.post<TokenResponse>("/api/v1/auth/register", data)
    return response.data
  },

  async refreshToken(data: RefreshTokenRequest): Promise<TokenResponse> {
    const response = await apiClient.post<TokenResponse>("/api/v1/auth/refresh", data)
    return response.data
  },

  async getCurrentUser(): Promise<OfficerOut> {
    const response = await apiClient.get<OfficerOut>("/api/v1/auth/me")
    return response.data
  },

  logout(): void {
    apiClient.logout()
  },

  isAuthenticated(): boolean {
    return apiClient.isAuthenticated()
  },
}
