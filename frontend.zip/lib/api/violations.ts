import { apiClient } from "./client"
import type {
  ViolationOut,
  ViolationCreate,
  ViolationUpdate,
  ViolationVersionOut,
  PaginatedViolations,
  ViolationFilters,
} from "./types"

export const violationsApi = {
  async getAll(filters?: ViolationFilters): Promise<PaginatedViolations> {
    const response = await apiClient.get<PaginatedViolations>("/api/v1/violations", { params: filters })
    return response.data
  },

  async getById(id: string): Promise<ViolationOut> {
    const response = await apiClient.get<ViolationOut>(`/api/v1/violations/${id}`)
    return response.data
  },

  async create(data: ViolationCreate): Promise<ViolationOut> {
    const response = await apiClient.post<ViolationOut>("/api/v1/violations", data)
    return response.data
  },

  async update(id: string, data: ViolationUpdate): Promise<ViolationOut> {
    const response = await apiClient.patch<ViolationOut>(`/api/v1/violations/${id}`, data)
    return response.data
  },

  async archive(id: string): Promise<ViolationOut> {
    const response = await apiClient.delete<ViolationOut>(`/api/v1/violations/${id}`)
    return response.data
  },

  async getHistory(id: string): Promise<ViolationVersionOut[]> {
    const response = await apiClient.get<ViolationVersionOut[]>(`/api/v1/violations/${id}/history`)
    return response.data
  },

  async rollback(id: string, versionId: string): Promise<ViolationOut> {
    const response = await apiClient.post<ViolationOut>(`/api/v1/violations/${id}/rollback/${versionId}`)
    return response.data
  },
}
