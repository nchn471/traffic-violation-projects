import { apiClient } from "./client"
import type { CameraOut, CameraCreate, CameraUpdate } from "./types"

export const camerasApi = {
  async getAll(): Promise<CameraOut[]> {
    const response = await apiClient.get<CameraOut[]>("/api/v1/cameras/")
    return response.data
  },

  async getById(id: string): Promise<CameraOut> {
    const response = await apiClient.get<CameraOut>(`/api/v1/cameras/${id}`)
    return response.data
  },

  async create(data: CameraCreate): Promise<CameraOut> {
    const response = await apiClient.post<CameraOut>("/api/v1/cameras/", data)
    return response.data
  },

  async update(id: string, data: CameraUpdate): Promise<CameraOut> {
    const response = await apiClient.patch<CameraOut>(`/api/v1/cameras/${id}`, data)
    return response.data
  },

  async delete(id: string): Promise<void> {
    await apiClient.delete(`/api/v1/cameras/${id}`)
  },

  async getVideos(id: string): Promise<string[]> {
    const response = await apiClient.get<string[]>(`/api/v1/cameras/${id}/videos`)
    return response.data
  },
}
