import { apiClient } from "./client"

export const mediaApi = {
  async getFile(filePath: string): Promise<Blob> {
    const response = await apiClient.get(`/api/v1/media/${filePath}`, { responseType: "blob" })
    return response.data
  },

  getImageUrl(filePath: string): string {
    const baseUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000"
    return `${baseUrl}/api/v1/media/${filePath}`
  },
}
