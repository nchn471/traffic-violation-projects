import { apiClient } from "./client"
import type { TicketOut, TicketCreate, TicketUpdate, PaginatedTickets } from "./types"

export const ticketsApi = {
  async getAll(filters?: { page?: number; limit?: number }): Promise<PaginatedTickets> {
    const response = await apiClient.get<PaginatedTickets>("/api/v1/tickets", { params: filters })
    return response.data
  },

  async create(violationId: string, data: TicketCreate): Promise<TicketOut> {
    const response = await apiClient.post<TicketOut>(`/api/v1/tickets/${violationId}`, data)
    return response.data
  },

  async getById(id: string): Promise<TicketOut> {
    const response = await apiClient.get<TicketOut>(`/api/v1/tickets/${id}`)
    return response.data
  },

  async update(id: string, data: TicketUpdate): Promise<TicketOut> {
    const response = await apiClient.patch<TicketOut>(`/api/v1/tickets/${id}`, data)
    return response.data
  },

  async archive(id: string): Promise<TicketOut> {
    const response = await apiClient.delete<TicketOut>(`/api/v1/tickets/${id}`)
    return response.data
  },

  async rollback(id: string, versionId: string): Promise<TicketOut> {
    const response = await apiClient.post<TicketOut>(`/api/v1/tickets/${id}/rollback/${versionId}`)
    return response.data
  },

  async markPaid(id: string): Promise<TicketOut> {
    const response = await apiClient.post<TicketOut>(`/api/v1/tickets/${id}/mark-paid`)
    return response.data
  },

  async getPdf(id: string): Promise<Blob> {
    const response = await apiClient.get(`/api/v1/tickets/${id}/pdf`, { responseType: "blob" })
    return response.data
  },

  async sendEmail(id: string): Promise<TicketOut> {
    const response = await apiClient.post<TicketOut>(`/api/v1/tickets/${id}/send`)
    return response.data
  },
}
