import { apiClient } from "./client"

export const healthApi = {
  async ping(): Promise<any> {
    const response = await apiClient.get("/ping")
    return response.data
  },

  async root(): Promise<any> {
    const response = await apiClient.get("/")
    return response.data
  },
}
