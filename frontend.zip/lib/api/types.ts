// Common types
export interface ApiResponse<T> {
  data: T
  message?: string
}

export interface ApiError {
  detail:
    | string
    | Array<{
        loc: (string | number)[]
        msg: string
        type: string
      }>
}

export interface Pagination {
  page: number
  limit: number
  total: number
  totalPages: number
}

// Auth types
export interface LoginRequest {
  username: string
  password: string
}

export interface RegisterRequest {
  name?: string
  username: string
  password: string
  role: string
}

export interface TokenResponse {
  access_token: string
  refresh_token: string
  token_type: string
}

export interface RefreshTokenRequest {
  refresh_token: string
}

export interface OfficerOut {
  id: string
  name: string
  username: string
  role: string
  created_at: string
}

// Camera types
export interface CameraOut {
  id: string
  name: string
  location: string
  folder_path: string
  created_at: string
  updated_at: string
}

export interface CameraCreate {
  name: string
  location: string
  folder_path: string
}

export interface CameraUpdate {
  name?: string | null
  location?: string | null
  folder_path?: string | null
}

// Violation types
export interface ViolationOut {
  id: string
  camera_id: string
  timestamp: string
  vehicle_type: string | null
  violation_type: string
  license_plate: string | null
  confidence: number | null
  frame_image_path: string
  vehicle_image_path: string
  lp_image_path: string | null
  status: string | null
  version_id: string | null
}

export interface ViolationCreate {
  camera_id: string
  timestamp: string
  vehicle_type: string | null
  violation_type: string
  license_plate: string | null
  confidence: number | null
  frame_image_path: string
  vehicle_image_path: string
  lp_image_path: string | null
  status?: string | null // This has a default value of "pending"
}

export interface ViolationUpdate {
  vehicle_type?: string | null
  violation_type?: string | null
  license_plate?: string | null
  confidence?: number | null
  status?: string | null
  frame_image_path?: string | null
  vehicle_image_path?: string | null
  lp_image_path?: string | null
}

export interface ViolationVersionOut {
  id: string
  violation_id: string
  officer_id: string
  timestamp: string
  vehicle_type: string | null
  violation_type: string
  license_plate: string | null
  confidence: number | null
  frame_image_path: string
  vehicle_image_path: string
  lp_image_path: string | null
  updated_at: string
  change_type: string
}

export interface PaginatedViolations {
  pagination: Pagination
  data: ViolationOut[]
}

// Ticket types
export interface TicketOut {
  id: string
  amount: number
  name: string | null
  email: string | null
  notes: string | null
  violation_id: string | null
  officer_id: string | null
  status: string | null
  issued_at: string | null
  violation?: ViolationOut | null
  officer?: OfficerOut | null
}

export interface TicketCreate {
  amount: number
  name?: string | null
  email?: string | null
  notes?: string | null
  violation_id?: string | null
  officer_id?: string | null
  status?: string | null
  issued_at?: string | null
}

export interface TicketUpdate {
  amount?: number | null
  name?: string | null
  email?: string | null
  notes?: string | null
}

// Statistics types
export interface StatsOverview {
  total_violations: number
  average_per_day: number
  processed_ratio: number
  violations_by_type: Record<string, number>
  violations_by_camera: Record<string, number>
}

export interface WeekdayStats {
  weekday: string
  count: number
}

export interface WeeklyViolationStats {
  data: WeekdayStats[]
}

export interface HourlyStats {
  hour: number
  count: number
}

export interface HourlyViolationStats {
  data: HourlyStats[]
}

export interface ProcessingStats {
  processed: number
  unprocessed: number
  ratio: number
}

// Filter types
export interface ViolationFilters {
  page?: number
  limit?: number
  status?: string
  violation_type?: string
}

// Add missing ticket list endpoint type
export interface PaginatedTickets {
  pagination: Pagination
  data: TicketOut[]
}
