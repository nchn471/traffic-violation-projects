import { apiClient } from "./client"
import type { StatsOverview, WeeklyViolationStats, HourlyViolationStats, ProcessingStats } from "./types"

export const statsApi = {
  async getOverview(): Promise<StatsOverview> {
    const response = await apiClient.get<StatsOverview>("/api/v1/stats/overview")
    return response.data
  },

  async getWeeklyStats(): Promise<WeeklyViolationStats> {
    const response = await apiClient.get<WeeklyViolationStats>("/api/v1/stats/by-weekday")
    return response.data
  },

  async getHourlyStats(): Promise<HourlyViolationStats> {
    const response = await apiClient.get<HourlyViolationStats>("/api/v1/stats/by-hour")
    return response.data
  },

  async getProcessingStats(): Promise<ProcessingStats> {
    const response = await apiClient.get<ProcessingStats>("/api/v1/stats/processing-ratio")
    return response.data
  },
}
