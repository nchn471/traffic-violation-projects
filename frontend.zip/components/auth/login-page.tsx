"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Camera } from "lucide-react"
import LoginForm from "./login-form"

interface LoginPageProps {
  onSuccess?: () => void
}

export default function LoginPage({ onSuccess }: LoginPageProps) {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <Card className="w-full max-w-md shadow-xl">
        <CardHeader className="text-center space-y-4">
          <div className="mx-auto w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center">
            <Camera className="w-8 h-8 text-white" />
          </div>
          <div>
            <CardTitle className="text-2xl font-bold text-gray-900">Hệ thống giám sát giao thông</CardTitle>
            <CardDescription className="text-gray-600 mt-2">Đăng nhập để truy cập hệ thống</CardDescription>
          </div>
        </CardHeader>

        <CardContent>
          <LoginForm onSuccess={onSuccess} />

          <div className="mt-6 text-center text-sm text-gray-500">
            <p>Phiên bản 1.0.0</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
