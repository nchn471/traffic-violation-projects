"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Settings, Save, RotateCcw } from "lucide-react"

interface CameraConfig {
  video: string
  location: string
  roi: number[][]
  stop_line: number[][]
  light_roi: number[][]
  detection_type: string
  lanes: Array<{
    id: number
    polygon: number[][]
    allow_labels: string[]
  }>
}

interface CameraConfigDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  config: CameraConfig
  onConfigChange: (config: CameraConfig) => void
  availableVideos: string[]
}

const defaultConfig: CameraConfig = {
  video: "",
  location: "",
  roi: [
    [73, 718],
    [342, 330],
    [1061, 323],
    [1076, 331],
    [1019, 394],
    [1009, 453],
    [1026, 509],
    [1052, 572],
    [1096, 649],
    [1141, 717],
  ],
  stop_line: [
    [154, 566],
    [1066, 541],
  ],
  light_roi: [
    [650, 5],
    [700, 5],
    [700, 50],
    [650, 50],
  ],
  detection_type: "helmet",
  lanes: [
    {
      id: 1,
      polygon: [
        [76, 717],
        [274, 417],
        [543, 422],
        [492, 719],
      ],
      allow_labels: ["car", "truck"],
    },
    {
      id: 2,
      polygon: [
        [492, 719],
        [543, 422],
        [758, 440],
        [790, 717],
      ],
      allow_labels: ["motorcycle", "bicycle"],
    },
    {
      id: 3,
      polygon: [
        [790, 717],
        [758, 440],
        [1009, 429],
        [1172, 719],
      ],
      allow_labels: ["car", "motorcycle", "truck", "bicycle"],
    },
  ],
}

const vehicleTypes = ["car", "motorcycle", "truck", "bicycle", "bus"]
const detectionTypes = [
  { value: "helmet", label: "Mũ bảo hiểm" },
  { value: "red_light", label: "Đèn đỏ" },
  { value: "speed", label: "Tốc độ" },
  { value: "lane", label: "Làn đường" },
]

export default function CameraConfigDialog({
  open,
  onOpenChange,
  config,
  onConfigChange,
  availableVideos,
}: CameraConfigDialogProps) {
  const [localConfig, setLocalConfig] = useState<CameraConfig>(config)

  useEffect(() => {
    setLocalConfig(config)
  }, [config])

  const handleSave = () => {
    onConfigChange(localConfig)
    onOpenChange(false)
  }

  const handleReset = () => {
    setLocalConfig(defaultConfig)
  }

  const updateConfig = (updates: Partial<CameraConfig>) => {
    setLocalConfig((prev) => ({ ...prev, ...updates }))
  }

  const updateLane = (index: number, updates: Partial<(typeof localConfig.lanes)[0]>) => {
    const newLanes = [...localConfig.lanes]
    newLanes[index] = { ...newLanes[index], ...updates }
    setLocalConfig((prev) => ({ ...prev, lanes: newLanes }))
  }

  const toggleVehicleType = (laneIndex: number, vehicleType: string) => {
    const lane = localConfig.lanes[laneIndex]
    const newAllowLabels = lane.allow_labels.includes(vehicleType)
      ? lane.allow_labels.filter((v) => v !== vehicleType)
      : [...lane.allow_labels, vehicleType]

    updateLane(laneIndex, { allow_labels: newAllowLabels })
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Settings className="w-5 h-5" />
            <span>Cấu hình Camera</span>
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="basic" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="basic">Cơ bản</TabsTrigger>
            <TabsTrigger value="regions">Vùng phát hiện</TabsTrigger>
            <TabsTrigger value="lanes">Làn đường</TabsTrigger>
            <TabsTrigger value="advanced">Nâng cao</TabsTrigger>
          </TabsList>

          <TabsContent value="basic" className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Video nguồn</Label>
                <Select value={localConfig.video} onValueChange={(value) => updateConfig({ video: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Chọn video" />
                  </SelectTrigger>
                  <SelectContent>
                    {availableVideos.map((video) => (
                      <SelectItem key={video} value={video}>
                        {video}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Loại phát hiện</Label>
                <Select
                  value={localConfig.detection_type}
                  onValueChange={(value) => updateConfig({ detection_type: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {detectionTypes.map((type) => (
                      <SelectItem key={type.value} value={type.value}>
                        {type.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Vị trí camera</Label>
              <Input
                value={localConfig.location}
                onChange={(e) => updateConfig({ location: e.target.value })}
                placeholder="Nhập vị trí camera"
              />
            </div>
          </TabsContent>

          <TabsContent value="regions" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">ROI (Vùng quan tâm)</CardTitle>
                </CardHeader>
                <CardContent>
                  <Textarea
                    value={JSON.stringify(localConfig.roi, null, 2)}
                    onChange={(e) => {
                      try {
                        const roi = JSON.parse(e.target.value)
                        updateConfig({ roi })
                      } catch (error) {
                        // Invalid JSON, ignore
                      }
                    }}
                    rows={8}
                    className="font-mono text-xs"
                  />
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Vạch dừng</CardTitle>
                </CardHeader>
                <CardContent>
                  <Textarea
                    value={JSON.stringify(localConfig.stop_line, null, 2)}
                    onChange={(e) => {
                      try {
                        const stop_line = JSON.parse(e.target.value)
                        updateConfig({ stop_line })
                      } catch (error) {
                        // Invalid JSON, ignore
                      }
                    }}
                    rows={8}
                    className="font-mono text-xs"
                  />
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Vùng đèn tín hiệu</CardTitle>
                </CardHeader>
                <CardContent>
                  <Textarea
                    value={JSON.stringify(localConfig.light_roi, null, 2)}
                    onChange={(e) => {
                      try {
                        const light_roi = JSON.parse(e.target.value)
                        updateConfig({ light_roi })
                      } catch (error) {
                        // Invalid JSON, ignore
                      }
                    }}
                    rows={8}
                    className="font-mono text-xs"
                  />
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="lanes" className="space-y-4">
            <div className="space-y-4">
              {localConfig.lanes.map((lane, index) => (
                <Card key={lane.id}>
                  <CardHeader>
                    <CardTitle className="text-base flex items-center justify-between">
                      <span>Làn {lane.id}</span>
                      <Badge variant="outline">{lane.allow_labels.length} loại xe</Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label>Polygon tọa độ</Label>
                      <Textarea
                        value={JSON.stringify(lane.polygon, null, 2)}
                        onChange={(e) => {
                          try {
                            const polygon = JSON.parse(e.target.value)
                            updateLane(index, { polygon })
                          } catch (error) {
                            // Invalid JSON, ignore
                          }
                        }}
                        rows={4}
                        className="font-mono text-xs"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Phương tiện cho phép</Label>
                      <div className="flex flex-wrap gap-2">
                        {vehicleTypes.map((vehicle) => (
                          <Button
                            key={vehicle}
                            variant={lane.allow_labels.includes(vehicle) ? "default" : "outline"}
                            size="sm"
                            onClick={() => toggleVehicleType(index, vehicle)}
                          >
                            {vehicle}
                          </Button>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="advanced" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Cấu hình JSON hoàn chỉnh</CardTitle>
              </CardHeader>
              <CardContent>
                <Textarea
                  value={JSON.stringify(localConfig, null, 2)}
                  onChange={(e) => {
                    try {
                      const config = JSON.parse(e.target.value)
                      setLocalConfig(config)
                    } catch (error) {
                      // Invalid JSON, ignore
                    }
                  }}
                  rows={20}
                  className="font-mono text-xs"
                />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="flex justify-between pt-4 border-t">
          <Button variant="outline" onClick={handleReset}>
            <RotateCcw className="w-4 h-4 mr-2" />
            Đặt lại mặc định
          </Button>
          <div className="flex space-x-2">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Hủy
            </Button>
            <Button onClick={handleSave}>
              <Save className="w-4 h-4 mr-2" />
              Lưu cấu hình
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
