export const VIOLATION_TYPES = {
  red_light: "Vượt đèn đỏ",
  speeding: "Vượt tốc độ",
  no_helmet: "Không đội mũ bảo hiểm",
  wrong_lane: "Sai làn đường",
} as const

export const VIOLATION_STATUS = {
  pending: "Chờ xử lý",
  processed: "Đã xử lý",
  sent: "Đã gửi",
} as const

export const TICKET_STATUS = {
  pending: "Chờ xử lý",
  sent: "Đã gửi",
  paid: "Đã thanh toán",
} as const

export const VEHICLE_TYPES = ["car", "motorcycle", "truck", "bicycle", "bus"] as const

export const DETECTION_TYPES = [
  { value: "helmet", label: "Mũ bảo hiểm" },
  { value: "red_light", label: "Đèn đỏ" },
  { value: "speed", label: "Tốc độ" },
  { value: "lane", label: "Làn đường" },
] as const

export const USER_ROLES = {
  admin: "Quản trị viên",
  officer: "Cán bộ",
} as const

export const WEBSOCKET_URL = process.env.NEXT_PUBLIC_WS_URL || "ws://localhost:8080/camera-stream"
