export const validateEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return emailRegex.test(email)
}

export const validatePassword = (password: string): { isValid: boolean; errors: string[] } => {
  const errors: string[] = []

  if (password.length < 6) {
    errors.push("Mật khẩu phải có ít nhất 6 ký tự")
  }

  if (!/[A-Za-z]/.test(password)) {
    errors.push("Mật khẩu phải chứa ít nhất một chữ cái")
  }

  if (!/[0-9]/.test(password)) {
    errors.push("Mật khẩu phải chứa ít nhất một số")
  }

  return {
    isValid: errors.length === 0,
    errors,
  }
}

export const validateUsername = (username: string): { isValid: boolean; errors: string[] } => {
  const errors: string[] = []

  if (username.length < 3) {
    errors.push("Tên đăng nhập phải có ít nhất 3 ký tự")
  }

  if (username.length > 50) {
    errors.push("Tên đăng nhập không được quá 50 ký tự")
  }

  if (!/^[a-zA-Z0-9_]+$/.test(username)) {
    errors.push("Tên đăng nhập chỉ được chứa chữ cái, số và dấu gạch dưới")
  }

  return {
    isValid: errors.length === 0,
    errors,
  }
}

export const validateRequired = (value: string, fieldName: string): string | null => {
  if (!value || value.trim().length === 0) {
    return `${fieldName} là bắt buộc`
  }
  return null
}

export const validateNumber = (value: string, min?: number, max?: number): string | null => {
  const num = Number.parseFloat(value)

  if (isNaN(num)) {
    return "Giá trị phải là số"
  }

  if (min !== undefined && num < min) {
    return `Giá trị phải lớn hơn hoặc bằng ${min}`
  }

  if (max !== undefined && num > max) {
    return `Giá trị phải nhỏ hơn hoặc bằng ${max}`
  }

  return null
}
