export const formatDateTime = (timestamp: string): string => {
  return new Date(timestamp).toLocaleString("vi-VN")
}

export const formatDate = (timestamp: string): string => {
  return new Date(timestamp).toLocaleDateString("vi-VN")
}

export const formatTime = (timestamp: string): string => {
  return new Date(timestamp).toLocaleTimeString("vi-VN")
}

export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat("vi-VN", {
    style: "currency",
    currency: "VND",
  }).format(amount)
}

export const formatPercentage = (value: number, decimals = 1): string => {
  return `${(value * 100).toFixed(decimals)}%`
}

export const formatConfidence = (confidence: number | null): string => {
  if (confidence === null) return "N/A"
  return `${(confidence * 100).toFixed(1)}%`
}

export const truncateId = (id: string, length = 8): string => {
  return `${id.slice(0, length)}...`
}
